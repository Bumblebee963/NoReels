# InstaGuard (Android)

An open-source, 100% local, ad-free Android Accessibility companion for the **official Instagram app** that combines all three distraction-blocking goals in one lightweight app:

1. **Block Reels & Explore on the Bottom Bar:** Places touch-blocking overlays directly over the Reels and Explore icons and automatically navigates back if either tab opens.
2. **Following-Only Feed:** Automatically switches Instagram's Home feed to the chronological **Following** view, skips `"Suggested for you"` cards, and includes a built-in **30-day Snooze Reminder**.
3. **DM Single-Post Lock:** Lets you open and watch a post or reel sent to you in DMs, then immediately returns to the chat if you try to scroll or swipe to another post.

---

## How to Build the APK

### Option A: Android Studio (Recommended)
1. Unzip `InstaGuard-Android.zip`.
2. Open **Android Studio** → **Open** → select the `InstaGuard-Android` folder.
3. Let Gradle sync finish (requires JDK 17 and Android SDK 35).
4. Connect your Android phone (with USB Debugging enabled) and click **Run ▶**, OR click **Build → Build Bundle(s) / APK(s) → Build APK(s)** and copy `app/build/outputs/apk/debug/app-debug.apk` to your phone.

### Option B: Build APK in the Cloud (No Android Studio Needed)
1. Create a free GitHub repository and upload the unzipped files.
2. Open the **Actions** tab → **Build InstaGuard APK** → **Run workflow**.
3. Download the compiled `InstaGuard-debug-apk` zip from the finished run, extract `app-debug.apk`, and install it on your Android phone.

---

## First-Time Phone Setup
1. Install `app-debug.apk` and open **InstaGuard**.
2. Tap **Enable Accessibility Service** → **Installed apps** → **InstaGuard** → turn **ON**.
   *(On Android 13+, if Android says "Restricted setting", open **Settings → Apps → InstaGuard → ⋮ (top-right) → Allow restricted settings**, then enable Accessibility.)*
3. Set InstaGuard's battery setting to **Unrestricted** so Android keeps it running in the background.
4. In Instagram, also turn on **Settings and activity → Content preferences → Snooze suggested posts in feed**, then tap **Set 30-Day Snooze Reminder** inside InstaGuard.
