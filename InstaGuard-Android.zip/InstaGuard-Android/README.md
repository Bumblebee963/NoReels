# InstaGuard (Android) — v1.1.0

An open-source, 100% local, ad-free Android Accessibility companion for the **official Instagram app** that combines all three distraction-blocking goals in one lightweight app:

1. **Block Reels & Explore on the Bottom Bar:** Places touch-blocking overlays directly over the Reels and Explore icons and automatically navigates back if either tab opens.
2. **Following-Only Feed (Improved in v1.1.0):** Reliably switches Instagram's Home feed to the chronological **Following** view via the top-left header switcher, detects both `"Suggested for you"` cards and non-followed `"Follow"` buttons in the feed, and includes a built-in **30-day Snooze Reminder**.
3. **DM Single-Post Lock:** Lets you open and watch a post or reel sent to you in DMs, then immediately returns to the chat if you try to scroll or swipe to another post.
