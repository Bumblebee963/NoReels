package com.instaguard.app

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.instaguard.app.data.PrefsManager
import com.instaguard.app.databinding.ActivityMainBinding
import com.instaguard.app.receiver.SnoozeReminderReceiver
import com.instaguard.app.service.InstagramGuardService
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: PrefsManager
    private var settingsUnlocked = true
    private var holdTimer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = PrefsManager(this)

        setupToggleListeners()
        setupButtons()
        setupStrictModeHoldButton()
    }

    override fun onResume() {
        super.onResume()
        settingsUnlocked = !prefs.strictModeEnabled
        syncUiState()
    }

    private fun setupToggleListeners() {
        binding.switchBlockReels.setOnCheckedChangeListener { _, checked ->
            prefs.blockReelsTab = checked
        }
        binding.switchBlockExplore.setOnCheckedChangeListener { _, checked ->
            prefs.blockExploreTab = checked
        }
        binding.switchOverlayShield.setOnCheckedChangeListener { _, checked ->
            prefs.overlayBlockBottomButtons = checked
        }
        binding.switchAutoFollowing.setOnCheckedChangeListener { _, checked ->
            prefs.autoSwitchFollowingFeed = checked
        }
        binding.switchBlockSuggested.setOnCheckedChangeListener { _, checked ->
            prefs.blockSuggestedPosts = checked
        }
        binding.switchDmSinglePost.setOnCheckedChangeListener { _, checked ->
            prefs.allowSingleDmPostOnly = checked
        }
        binding.switchStrictMode.setOnCheckedChangeListener { _, checked ->
            prefs.strictModeEnabled = checked
            if (checked) {
                settingsUnlocked = false
                applyLockState()
            }
        }
    }

    private fun setupButtons() {
        binding.btnEnableService.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnOpenInstagram.setOnClickListener {
            val launchIntent = packageManager.getLaunchIntentForPackage("com.instagram.android")
            if (launchIntent != null) {
                startActivity(launchIntent)
            } else {
                Toast.makeText(this, "Instagram is not installed on this device.", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnSnoozeReminder.setOnClickListener {
            schedule30DaySnoozeReminder()
        }
    }

    private fun setupStrictModeHoldButton() {
        binding.btnHoldToUnlock.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    holdTimer?.cancel()
                    holdTimer = object : CountDownTimer(10_000L, 1_000L) {
                        override fun onTick(millisUntilFinished: Long) {
                            val sec = (millisUntilFinished / 1000L) + 1
                            binding.btnHoldToUnlock.text = "Keep holding... ${sec}s"
                        }

                        override fun onFinish() {
                            settingsUnlocked = true
                            applyLockState()
                            Toast.makeText(this@MainActivity, "Settings unlocked", Toast.LENGTH_SHORT).show()
                        }
                    }.start()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    holdTimer?.cancel()
                    binding.btnHoldToUnlock.text = "Hold 10 seconds to unlock settings"
                    true
                }
                else -> false
            }
        }
    }

    private fun syncUiState() {
        binding.switchBlockReels.isChecked = prefs.blockReelsTab
        binding.switchBlockExplore.isChecked = prefs.blockExploreTab
        binding.switchOverlayShield.isChecked = prefs.overlayBlockBottomButtons
        binding.switchAutoFollowing.isChecked = prefs.autoSwitchFollowingFeed
        binding.switchBlockSuggested.isChecked = prefs.blockSuggestedPosts
        binding.switchDmSinglePost.isChecked = prefs.allowSingleDmPostOnly
        binding.switchStrictMode.isChecked = prefs.strictModeEnabled

        val active = isAccessibilityServiceEnabled()
        binding.tvStatusBadge.text = getString(if (active) R.string.status_active else R.string.status_inactive)
        binding.tvStatusBadge.setBackgroundColor(
            ContextCompat.getColor(this, if (active) R.color.status_green_bg else R.color.status_amber_bg)
        )
        binding.tvStatusBadge.setTextColor(
            ContextCompat.getColor(this, if (active) R.color.status_green_text else R.color.status_amber_text)
        )

        binding.tvStatsSummary.text =
            "Blocked today: ${prefs.getReelsBlockedToday()} Reels  •  " +
                "${prefs.getExploreBlockedToday()} Explore  •  " +
                "${prefs.getDmScrollBlockedToday()} DM Scrolls  •  " +
                "${prefs.getSuggestedBlockedToday()} Suggested"

        applyLockState()
    }

    private fun applyLockState() {
        val enabled = settingsUnlocked
        binding.switchBlockReels.isEnabled = enabled
        binding.switchBlockExplore.isEnabled = enabled
        binding.switchOverlayShield.isEnabled = enabled
        binding.switchAutoFollowing.isEnabled = enabled
        binding.switchBlockSuggested.isEnabled = enabled
        binding.switchDmSinglePost.isEnabled = enabled
        binding.switchStrictMode.isEnabled = enabled
        binding.btnHoldToUnlock.visibility = if (enabled) View.GONE else View.VISIBLE
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return enabledServices.any {
            it.resolveInfo.serviceInfo.packageName == packageName &&
                it.resolveInfo.serviceInfo.name == InstagramGuardService::class.java.name
        }
    }

    private fun schedule30DaySnoozeReminder() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }

        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, SnoozeReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val triggerAt = System.currentTimeMillis() + TimeUnit.DAYS.toMillis(30)
        alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        Toast.makeText(this, getString(R.string.snooze_reminder_scheduled), Toast.LENGTH_LONG).show()
    }
}
