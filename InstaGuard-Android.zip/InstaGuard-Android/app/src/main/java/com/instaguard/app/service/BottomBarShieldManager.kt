package com.instaguard.app.service

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast

/**
 * Places lightweight TYPE_ACCESSIBILITY_OVERLAY shields directly over Instagram's
 * Reels and Explore bottom-bar buttons so taps are intercepted before Instagram receives them.
 * Requires no extra SYSTEM_ALERT_WINDOW permission because it runs inside AccessibilityService.
 */
class BottomBarShieldManager(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val activeOverlays = mutableMapOf<String, View>()
    private val lastRects = mutableMapOf<String, Rect>()

    fun updateShield(key: String, bounds: Rect?, label: String) {
        if (bounds == null || bounds.width() <= 0 || bounds.height() <= 0) {
            removeShield(key)
            return
        }

        if (lastRects[key] == bounds && activeOverlays.containsKey(key)) {
            return
        }

        removeShield(key)

        val shieldView = View(context).apply {
            setBackgroundColor(Color.argb(120, 15, 23, 42))
            isClickable = true
            isFocusable = false
            setOnClickListener {
                Toast.makeText(context, "$label is blocked by InstaGuard", Toast.LENGTH_SHORT).show()
            }
        }

        val params = WindowManager.LayoutParams(
            bounds.width(),
            bounds.height(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = bounds.left
            y = bounds.top
        }

        try {
            windowManager.addView(shieldView, params)
            activeOverlays[key] = shieldView
            lastRects[key] = Rect(bounds)
        } catch (_: Exception) {
            // Ignore transient window token errors when Instagram is transitioning
        }
    }

    fun removeShield(key: String) {
        activeOverlays.remove(key)?.let { view ->
            try {
                windowManager.removeViewImmediate(view)
            } catch (_: Exception) {
            }
        }
        lastRects.remove(key)
    }

    fun clearAll() {
        activeOverlays.keys.toList().forEach { removeShield(it) }
    }
}
