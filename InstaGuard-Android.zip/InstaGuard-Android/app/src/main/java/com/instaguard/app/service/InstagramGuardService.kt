package com.instaguard.app.service

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import com.instaguard.app.data.PrefsManager

/**
 * Core accessibility engine for InstaGuard.
 *
 * Enforces all three user goals on top of the official Android Instagram app:
 * 1. Blocks the Reels and Explore tabs (both via touch shields and instant navigation back).
 * 2. Keeps the feed Following-only (auto-switches to Following feed + skips Suggested posts).
 * 3. Allows viewing 1 post/reel opened from DMs, then blocks any subsequent scroll/swipe.
 */
class InstagramGuardService : AccessibilityService() {

    private lateinit var prefs: PrefsManager
    private lateinit var shieldManager: BottomBarShieldManager

    private enum class ScreenContext {
        UNKNOWN,
        HOME_FEED,
        DM_THREAD,
        DM_SINGLE_MEDIA,
        REELS_TAB,
        EXPLORE_TAB
    }

    private var currentContext: ScreenContext = ScreenContext.UNKNOWN
    private var lastDmThreadSeenMs: Long = 0L
    private var dmMediaEnteredMs: Long = 0L
    private var dmInitialMediaFingerprint: String? = null
    private var lastActionMs: Long = 0L
    private var switchedFollowingThisSession: Boolean = false
    private var pendingFollowingDropdownTapMs: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = PrefsManager(this)
        shieldManager = BottomBarShieldManager(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        if (pkg != INSTAGRAM_PACKAGE) {
            shieldManager.clearAll()
            switchedFollowingThisSession = false
            return
        }

        val root = rootInActiveWindow ?: return
        val now = SystemClock.elapsedRealtime()

        // Step A: Keep bottom-bar touch shields synced over Reels & Explore icons
        syncBottomBarShields(root)

        // Step B: If we recently opened the Instagram header dropdown, tap "Following"
        if (pendingFollowingDropdownTapMs > 0 && now - pendingFollowingDropdownTapMs < 2500L) {
            if (clickNodeByExactText(root, "Following")) {
                pendingFollowingDropdownTapMs = 0L
                switchedFollowingThisSession = true
                return
            }
        }

        // Step C: Detect DM thread presence (tracks context for Goal 3)
        if (isInsideDmThread(root)) {
            currentContext = ScreenContext.DM_THREAD
            lastDmThreadSeenMs = now
            dmInitialMediaFingerprint = null
            return
        }

        // Step D: Goal 3 — Handle media/reel opened directly from a DM thread
        val isMediaViewerOpen = isReelsViewerVisible(root) || isSinglePostViewerVisible(root)
        val openedFromDmRecently = (now - lastDmThreadSeenMs) <= DM_TRANSITION_WINDOW_MS

        if (prefs.allowSingleDmPostOnly && isMediaViewerOpen &&
            (currentContext == ScreenContext.DM_SINGLE_MEDIA || openedFromDmRecently)
        ) {
            handleDmSingleMedia(event, root, now)
            return
        }

        // Leaving DM media viewer resets the DM lock state
        if (currentContext == ScreenContext.DM_SINGLE_MEDIA && !isMediaViewerOpen) {
            currentContext = ScreenContext.UNKNOWN
            dmInitialMediaFingerprint = null
        }

        // Step E: Goal 1 — Block Reels Tab
        if (prefs.blockReelsTab && isReelsTabSelectedOrActive(root)) {
            currentContext = ScreenContext.REELS_TAB
            if (canTriggerAction(now)) {
                prefs.incrementReelsBlocked()
                navigateAway("Reels blocked by InstaGuard")
            }
            return
        }

        // Step F: Goal 1 — Block Explore Tab
        if (prefs.blockExploreTab && isExploreTabSelectedOrActive(root)) {
            currentContext = ScreenContext.EXPLORE_TAB
            if (canTriggerAction(now)) {
                prefs.incrementExploreBlocked()
                navigateAway("Explore blocked by InstaGuard")
            }
            return
        }

        // Step G: Goal 2 — Following-only Home feed & Suggested posts guard
        if (isHomeFeedVisible(root)) {
            currentContext = ScreenContext.HOME_FEED
            handleFollowingOnlyFeed(root, now)
        }
    }

    override fun onInterrupt() {
        shieldManager.clearAll()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::shieldManager.isInitialized) {
            shieldManager.clearAll()
        }
    }

    // -----------------------------------------------------------------------
    // Goal 1: Bottom-bar shields & Reels/Explore detection
    // -----------------------------------------------------------------------

    private fun syncBottomBarShields(root: AccessibilityNodeInfo) {
        if (!prefs.overlayBlockBottomButtons) {
            shieldManager.clearAll()
            return
        }

        val reelsBounds = if (prefs.blockReelsTab) findTabBounds(root, REELS_TAB_IDS, REELS_DESC_KEYWORDS) else null
        val exploreBounds = if (prefs.blockExploreTab) findTabBounds(root, EXPLORE_TAB_IDS, EXPLORE_DESC_KEYWORDS) else null

        shieldManager.updateShield("reels_tab", reelsBounds, "Reels")
        shieldManager.updateShield("explore_tab", exploreBounds, "Explore")
    }

    private fun findTabBounds(
        root: AccessibilityNodeInfo,
        idHints: List<String>,
        descHints: List<String>
    ): Rect? {
        for (id in idHints) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            val match = nodes.firstOrNull { it.isVisibleToUser }
            if (match != null) {
                val rect = Rect()
                match.getBoundsInScreen(rect)
                if (rect.width() > 10 && rect.height() > 10) return rect
            }
        }
        return findBoundsByContentDesc(root, descHints)
    }

    private fun isReelsTabSelectedOrActive(root: AccessibilityNodeInfo): Boolean {
        for (id in REELS_TAB_IDS) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            if (nodes.any { it.isSelected }) return true
        }
        return isReelsViewerVisible(root)
    }

    private fun isExploreTabSelectedOrActive(root: AccessibilityNodeInfo): Boolean {
        for (id in EXPLORE_TAB_IDS) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            if (nodes.any { it.isSelected }) return true
        }
        for (id in EXPLORE_SURFACE_IDS) {
            if (root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id").isNotEmpty()) {
                return true
            }
        }
        return false
    }

    private fun isReelsViewerVisible(root: AccessibilityNodeInfo): Boolean {
        for (id in REELS_VIEWER_IDS) {
            if (root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id").isNotEmpty()) {
                return true
            }
        }
        return false
    }

    private fun isSinglePostViewerVisible(root: AccessibilityNodeInfo): Boolean {
        for (id in POST_VIEWER_IDS) {
            if (root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id").isNotEmpty()) {
                return true
            }
        }
        return false
    }

    // -----------------------------------------------------------------------
    // Goal 2: Following-Only Feed & Suggested Posts Guard
    // -----------------------------------------------------------------------

    private fun isHomeFeedVisible(root: AccessibilityNodeInfo): Boolean {
        for (id in HOME_TAB_IDS) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            if (nodes.any { it.isSelected }) return true
        }
        return false
    }

    private fun handleFollowingOnlyFeed(root: AccessibilityNodeInfo, now: Long) {
        // Already on the Following feed? Nothing to block.
        if (containsExactText(root, "Following") && !containsExactText(root, "Suggested for you")) {
            return
        }

        // Option 2A: Auto-switch to Instagram's chronological Following feed once per session
        if (prefs.autoSwitchFollowingFeed && !switchedFollowingThisSession && canTriggerAction(now)) {
            if (clickHeaderInstagramLogo(root)) {
                pendingFollowingDropdownTapMs = now
                lastActionMs = now
                return
            }
        }

        // Option 2B: If a "Suggested for you" or "Suggested reels" card is visible, jump back to top
        if (prefs.blockSuggestedPosts && hasSuggestedContent(root) && canTriggerAction(now)) {
            prefs.incrementSuggestedBlocked()
            lastActionMs = now
            // Tapping the Home tab scrolls smoothly back to the top of followed posts
            if (!clickHomeTab(root)) {
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
            Toast.makeText(this, "Suggested post skipped by InstaGuard", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hasSuggestedContent(root: AccessibilityNodeInfo): Boolean {
        for (phrase in SUGGESTED_PHRASES) {
            if (root.findAccessibilityNodeInfosByText(phrase).isNotEmpty()) {
                return true
            }
        }
        return false
    }

    private fun clickHeaderInstagramLogo(root: AccessibilityNodeInfo): Boolean {
        for (id in HEADER_LOGO_IDS) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            val clickable = nodes.firstOrNull { it.isVisibleToUser && it.isClickable }
            if (clickable != null) {
                return clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
        }
        return false
    }

    private fun clickHomeTab(root: AccessibilityNodeInfo): Boolean {
        for (id in HOME_TAB_IDS) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            val target = nodes.firstOrNull { it.isVisibleToUser }
            if (target != null) {
                return target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
        }
        return false
    }

    // -----------------------------------------------------------------------
    // Goal 3: DM Single-Post Lock (Allow 1 post/reel from DM, block scrolling)
    // -----------------------------------------------------------------------

    private fun isInsideDmThread(root: AccessibilityNodeInfo): Boolean {
        for (id in DM_THREAD_IDS) {
            if (root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id").isNotEmpty()) {
                return true
            }
        }
        return root.findAccessibilityNodeInfosByText("Message...").isNotEmpty()
    }

    private fun handleDmSingleMedia(
        event: AccessibilityEvent,
        root: AccessibilityNodeInfo,
        now: Long
    ) {
        if (currentContext != ScreenContext.DM_SINGLE_MEDIA) {
            currentContext = ScreenContext.DM_SINGLE_MEDIA
            dmMediaEnteredMs = now
            dmInitialMediaFingerprint = extractMediaFingerprint(root)
            return
        }

        // Give the initial DM post 700ms to finish its opening animation
        if (now - dmMediaEnteredMs < 700L) {
            if (dmInitialMediaFingerprint.isNullOrBlank()) {
                dmInitialMediaFingerprint = extractMediaFingerprint(root)
            }
            return
        }

        // Trigger 1: User attempted to scroll vertically inside the DM post/reel viewer
        val isVerticalScroll = event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED &&
            (event.scrollDeltaY != 0 || event.fromIndex > 0)

        // Trigger 2: The visible post/reel author/caption changed to a different item
        val currentFingerprint = extractMediaFingerprint(root)
        val itemChanged = !dmInitialMediaFingerprint.isNullOrBlank() &&
            !currentFingerprint.isNullOrBlank() &&
            currentFingerprint != dmInitialMediaFingerprint

        if ((isVerticalScroll || itemChanged) && canTriggerAction(now)) {
            prefs.incrementDmScrollBlocked()
            currentContext = ScreenContext.DM_THREAD
            dmInitialMediaFingerprint = null
            navigateAway("Scrolling after DM post is blocked")
        }
    }

    private fun extractMediaFingerprint(root: AccessibilityNodeInfo): String? {
        for (id in MEDIA_AUTHOR_IDS) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            val text = nodes.firstOrNull { !it.text.isNullOrBlank() }?.text?.toString()
            if (!text.isNullOrBlank()) return text.trim()
        }
        return null
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    private fun canTriggerAction(now: Long): Boolean = (now - lastActionMs) > ACTION_COOLDOWN_MS

    private fun navigateAway(message: String) {
        lastActionMs = SystemClock.elapsedRealtime()
        performGlobalAction(GLOBAL_ACTION_BACK)
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun clickNodeByExactText(root: AccessibilityNodeInfo, text: String): Boolean {
        val matches = root.findAccessibilityNodeInfosByText(text)
        for (node in matches) {
            if (node.text?.toString()?.equals(text, ignoreCase = true) == true) {
                var target: AccessibilityNodeInfo? = node
                while (target != null && !target.isClickable) {
                    target = target.parent
                }
                if (target != null && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }
            }
        }
        return false
    }

    private fun containsExactText(root: AccessibilityNodeInfo, text: String): Boolean {
        return root.findAccessibilityNodeInfosByText(text)
            .any { it.text?.toString()?.equals(text, ignoreCase = true) == true }
    }

    private fun findBoundsByContentDesc(
        node: AccessibilityNodeInfo,
        keywords: List<String>,
        depth: Int = 0
    ): Rect? {
        if (depth > 8) return null
        val desc = node.contentDescription?.toString()?.lowercase()
        if (desc != null && keywords.any { desc == it || desc.startsWith("$it,") }) {
            val rect = Rect()
            node.getBoundsInScreen(rect)
            if (rect.width() > 10 && rect.height() > 10) return rect
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findBoundsByContentDesc(child, keywords, depth + 1)
            if (found != null) return found
        }
        return null
    }

    companion object {
        private const val INSTAGRAM_PACKAGE = "com.instagram.android"
        private const val ACTION_COOLDOWN_MS = 650L
        private const val DM_TRANSITION_WINDOW_MS = 3500L

        private val HOME_TAB_IDS = listOf("feed_tab", "tab_home")
        private val REELS_TAB_IDS = listOf("clips_tab", "reels_tab")
        private val EXPLORE_TAB_IDS = listOf("search_tab", "explore_tab")
        private val REELS_DESC_KEYWORDS = listOf("reels")
        private val EXPLORE_DESC_KEYWORDS = listOf("search and explore", "explore")

        private val REELS_VIEWER_IDS = listOf(
            "clips_viewer_view_pager",
            "clips_video_container",
            "clips_swipe_refresh_container"
        )
        private val EXPLORE_SURFACE_IDS = listOf(
            "explore_grid",
            "discovery_surface",
            "action_bar_search_edit_text"
        )
        private val POST_VIEWER_IDS = listOf(
            "row_feed_photo_imageview",
            "media_group",
            "zoomable_view_container"
        )
        private val HEADER_LOGO_IDS = listOf(
            "title_logo",
            "action_bar_title",
            "feed_title_logo"
        )
        private val DM_THREAD_IDS = listOf(
            "row_thread_composer_edittext",
            "message_list",
            "thread_title"
        )
        private val MEDIA_AUTHOR_IDS = listOf(
            "clips_author_username",
            "row_feed_photo_profile_name",
            "username"
        )
        private val SUGGESTED_PHRASES = listOf(
            "Suggested for you",
            "Suggested reels",
            "Because you watched",
            "Suggested Posts"
        )
    }
}
