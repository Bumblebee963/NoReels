package com.instaguard.app.service

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import com.instaguard.app.data.PrefsManager

/**
 * Core accessibility engine for InstaGuard (v1.1.0).
 *
 * Enforces all three user goals on top of the official Android Instagram app:
 * 1. Blocks the Reels and Explore tabs (both via touch shields and instant navigation back).
 * 2. Keeps the feed Following-only (reliably auto-switches to the Following feed via header
 *    dropdown + detects both "Suggested for you" cards and non-followed "Follow" buttons).
 * 3. Allows viewing 1 post/reel opened from DMs, then blocks any subsequent scroll/swipe.
 */
class InstagramGuardService : AccessibilityService() {

    private lateinit var prefs: PrefsManager
    private lateinit var shieldManager: BottomBarShieldManager

    private enum class ScreenContext {
        UNKNOWN,
        HOME_FEED,
        DM_THREAD,
        DM_SINGLE_MEDIA,
        REELS_TAB,
        EXPLORE_TAB
    }

    private var currentContext: ScreenContext = ScreenContext.UNKNOWN
    private var lastDmThreadSeenMs: Long = 0L
    private var dmMediaEnteredMs: Long = 0L
    private var dmInitialMediaFingerprint: String? = null
    private var lastActionMs: Long = 0L
    private var lastFollowingSwitchAttemptMs: Long = 0L
    private var pendingFollowingDropdownTapMs: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = PrefsManager(this)
        shieldManager = BottomBarShieldManager(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        if (pkg != INSTAGRAM_PACKAGE) {
            shieldManager.clearAll()
            lastFollowingSwitchAttemptMs = 0L
            pendingFollowingDropdownTapMs = 0L
            return
        }

        val root = rootInActiveWindow ?: return
        val now = SystemClock.elapsedRealtime()

        // Step A: Keep bottom-bar touch shields synced over Reels & Explore icons
        syncBottomBarShields(root)

        // Step B: If we recently opened the Instagram header dropdown, tap "Following"
        if (pendingFollowingDropdownTapMs > 0 && now - pendingFollowingDropdownTapMs < 3000L) {
            if (clickNodeByExactText(root, "Following")) {
                pendingFollowingDropdownTapMs = 0L
                lastActionMs = now
                return
            }
        }

        // Step C: Detect DM thread presence (tracks context for Goal 3)
        if (isInsideDmThread(root)) {
            currentContext = ScreenContext.DM_THREAD
            lastDmThreadSeenMs = now
            dmInitialMediaFingerprint = null
            return
        }

        // Step D: Goal 3 — Handle media/reel opened directly from a DM thread
        val isMediaViewerOpen = isReelsViewerVisible(root) || isSinglePostViewerVisible(root)
        val openedFromDmRecently = (now - lastDmThreadSeenMs) <= DM_TRANSITION_WINDOW_MS

        if (prefs.allowSingleDmPostOnly && isMediaViewerOpen &&
            (currentContext == ScreenContext.DM_SINGLE_MEDIA || openedFromDmRecently)
        ) {
            handleDmSingleMedia(event, root, now)
            return
        }

        // Leaving DM media viewer resets the DM lock state
        if (currentContext == ScreenContext.DM_SINGLE_MEDIA && !isMediaViewerOpen) {
            currentContext = ScreenContext.UNKNOWN
            dmInitialMediaFingerprint = null
        }

        // Step E: Goal 1 — Block Reels Tab
        if (prefs.blockReelsTab && isReelsTabSelectedOrActive(root)) {
            currentContext = ScreenContext.REELS_TAB
            if (canTriggerAction(now)) {
                prefs.incrementReelsBlocked()
                navigateAway("Reels blocked by InstaGuard")
            }
            return
        }

        // Step F: Goal 1 — Block Explore Tab
        if (prefs.blockExploreTab && isExploreTabSelectedOrActive(root)) {
            currentContext = ScreenContext.EXPLORE_TAB
            if (canTriggerAction(now)) {
                prefs.incrementExploreBlocked()
                navigateAway("Explore blocked by InstaGuard")
            }
            return
        }

        // Step G: Goal 2 — Following-only Home feed & Suggested/Unfollowed posts guard
        if (isHomeFeedVisible(root)) {
            currentContext = ScreenContext.HOME_FEED
            handleFollowingOnlyFeed(root, now)
        }
    }

    override fun onInterrupt() {
        shieldManager.clearAll()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::shieldManager.isInitialized) {
            shieldManager.clearAll()
        }
    }

    // -----------------------------------------------------------------------
    // Goal 1: Bottom-bar shields & Reels/Explore detection
    // -----------------------------------------------------------------------

    private fun syncBottomBarShields(root: AccessibilityNodeInfo) {
        if (!prefs.overlayBlockBottomButtons) {
            shieldManager.clearAll()
            return
        }

        val reelsBounds = if (prefs.blockReelsTab) findTabBounds(root, REELS_TAB_IDS, REELS_DESC_KEYWORDS) else null
        val exploreBounds = if (prefs.blockExploreTab) findTabBounds(root, EXPLORE_TAB_IDS, EXPLORE_DESC_KEYWORDS) else null

        shieldManager.updateShield("reels_tab", reelsBounds, "Reels")
        shieldManager.updateShield("explore_tab", exploreBounds, "Explore")
    }

    private fun findTabBounds(
        root: AccessibilityNodeInfo,
        idHints: List<String>,
        descHints: List<String>
    ): Rect? {
        for (id in idHints) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            val match = nodes.firstOrNull { it.isVisibleToUser }
            if (match != null) {
                val rect = Rect()
                match.getBoundsInScreen(rect)
                if (rect.width() > 10 && rect.height() > 10) return rect
            }
        }
        return findBoundsByContentDesc(root, descHints)
    }

    private fun isReelsTabSelectedOrActive(root: AccessibilityNodeInfo): Boolean {
        for (id in REELS_TAB_IDS) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            if (nodes.any { it.isSelected }) return true
        }
        return isReelsViewerVisible(root)
    }

    private fun isExploreTabSelectedOrActive(root: AccessibilityNodeInfo): Boolean {
        for (id in EXPLORE_TAB_IDS) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            if (nodes.any { it.isSelected }) return true
        }
        for (id in EXPLORE_SURFACE_IDS) {
            if (root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id").isNotEmpty()) {
                return true
            }
        }
        return false
    }

    private fun isReelsViewerVisible(root: AccessibilityNodeInfo): Boolean {
        for (id in REELS_VIEWER_IDS) {
            if (root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id").isNotEmpty()) {
                return true
            }
        }
        return false
    }

    private fun isSinglePostViewerVisible(root: AccessibilityNodeInfo): Boolean {
        for (id in POST_VIEWER_IDS) {
            if (root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id").isNotEmpty()) {
                return true
            }
        }
        return false
    }

    // -----------------------------------------------------------------------
    // Goal 2: Following-Only Feed & Non-Followed / Suggested Posts Guard
    // -----------------------------------------------------------------------

    private fun isHomeFeedVisible(root: AccessibilityNodeInfo): Boolean {
        for (id in HOME_TAB_IDS) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            if (nodes.any { it.isSelected }) return true
        }
        return false
    }

    private fun getScreenHeight(): Int = resources.displayMetrics.heightPixels

    /**
     * Checks strictly in the top header bar (top 14% of screen) whether the user is
     * already inside the chronological "Following" feed.
     */
    private fun isAlreadyOnFollowingFeed(root: AccessibilityNodeInfo): Boolean {
        val headerCutoff = (getScreenHeight() * 0.14f).toInt()
        val matches = root.findAccessibilityNodeInfosByText("Following")
        for (node in matches) {
            if (!node.isVisibleToUser) continue
            if (node.text?.toString()?.equals("Following", ignoreCase = true) == true) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                if (rect.top in 0..headerCutoff && rect.bottom <= headerCutoff + 80) {
                    return true
                }
            }
        }
        return false
    }

    private fun handleFollowingOnlyFeed(root: AccessibilityNodeInfo, now: Long) {
        // Already inside Instagram's chronological Following feed? All posts are from people you follow.
        if (isAlreadyOnFollowingFeed(root)) {
            return
        }

        // Option 2A: Automatically open the top-left Instagram dropdown to switch to "Following"
        if (prefs.autoSwitchFollowingFeed &&
            (now - lastFollowingSwitchAttemptMs) > FOLLOWING_RETRY_INTERVAL_MS &&
            canTriggerAction(now)
        ) {
            if (clickHeaderInstagramLogo(root)) {
                pendingFollowingDropdownTapMs = now
                lastFollowingSwitchAttemptMs = now
                lastActionMs = now
                return
            }
        }

        // Option 2B: Catch any "Suggested for you" card OR post from someone you don't follow ("Follow" button)
        if (prefs.blockSuggestedPosts && hasUnfollowedOrSuggestedPost(root) && canTriggerAction(now)) {
            prefs.incrementSuggestedBlocked()
            lastActionMs = now

            // First try switching to the Following feed if auto-switch is enabled
            if (prefs.autoSwitchFollowingFeed && clickHeaderInstagramLogo(root)) {
                pendingFollowingDropdownTapMs = now
                lastFollowingSwitchAttemptMs = now
                return
            }

            // Otherwise jump back to the top of the Home feed
            if (!clickHomeTab(root)) {
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
            Toast.makeText(this, "Non-followed post skipped by InstaGuard", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hasUnfollowedOrSuggestedPost(root: AccessibilityNodeInfo): Boolean {
        for (phrase in SUGGESTED_PHRASES) {
            val found = root.findAccessibilityNodeInfosByText(phrase)
            if (found.any { it.isVisibleToUser }) return true
        }

        // Detect feed posts from accounts you do not follow by checking for a visible "Follow" button
        // inside the feed body (between top header and bottom navigation bar).
        val screenH = getScreenHeight()
        val topFeedY = (screenH * 0.14f).toInt()
        val bottomFeedY = (screenH * 0.88f).toInt()

        for (id in FOLLOW_BUTTON_IDS) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            for (node in nodes) {
                if (!node.isVisibleToUser) continue
                val text = node.text?.toString()?.trim() ?: ""
                if (text.equals("Follow", ignoreCase = true)) {
                    val rect = Rect()
                    node.getBoundsInScreen(rect)
                    if (rect.top >= topFeedY && rect.bottom <= bottomFeedY) {
                        return true
                    }
                }
            }
        }

        val followTextNodes = root.findAccessibilityNodeInfosByText("Follow")
        for (node in followTextNodes) {
            if (!node.isVisibleToUser) continue
            val text = node.text?.toString()?.trim() ?: ""
            if (text.equals("Follow", ignoreCase = true)) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                if (rect.top >= topFeedY && rect.bottom <= bottomFeedY && rect.width() in 40..360) {
                    return true
                }
            }
        }

        return false
    }

    private fun clickHeaderInstagramLogo(root: AccessibilityNodeInfo): Boolean {
        val headerCutoff = (getScreenHeight() * 0.15f).toInt()

        for (id in HEADER_LOGO_IDS) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            for (node in nodes) {
                if (!node.isVisibleToUser) continue
                val rect = Rect()
                node.getBoundsInScreen(rect)
                if (rect.bottom <= headerCutoff + 80) {
                    if (clickSelfOrParent(node)) return true
                }
            }
        }

        // Fallback: find the Instagram logo / feed switcher in the top-left header by contentDescription
        val headerNode = findTopHeaderLogoNode(root, headerCutoff)
        if (headerNode != null) {
            return clickSelfOrParent(headerNode)
        }
        return false
    }

    private fun findTopHeaderLogoNode(
        node: AccessibilityNodeInfo,
        headerCutoff: Int,
        depth: Int = 0
    ): AccessibilityNodeInfo? {
        if (depth > 8) return null
        if (node.isVisibleToUser) {
            val desc = node.contentDescription?.toString()?.lowercase() ?: ""
            if (desc.contains("instagram") || desc.contains("for you") || desc.contains("home feed")) {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                if (rect.top in 0..headerCutoff && rect.bottom <= headerCutoff + 80) {
                    return node
                }
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val match = findTopHeaderLogoNode(child, headerCutoff, depth + 1)
            if (match != null) return match
        }
        return null
    }

    private fun clickSelfOrParent(node: AccessibilityNodeInfo): Boolean {
        var target: AccessibilityNodeInfo? = node
        var hops = 0
        while (target != null && hops < 4) {
            if (target.isClickable && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }
            target = target.parent
            hops++
        }
        return false
    }

    private fun clickHomeTab(root: AccessibilityNodeInfo): Boolean {
        for (id in HOME_TAB_IDS) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            val target = nodes.firstOrNull { it.isVisibleToUser }
            if (target != null) {
                return clickSelfOrParent(target)
            }
        }
        return false
    }

    // -----------------------------------------------------------------------
    // Goal 3: DM Single-Post Lock (Allow 1 post/reel from DM, block scrolling)
    // -----------------------------------------------------------------------

    private fun isInsideDmThread(root: AccessibilityNodeInfo): Boolean {
        for (id in DM_THREAD_IDS) {
            if (root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id").isNotEmpty()) {
                return true
            }
        }
        return root.findAccessibilityNodeInfosByText("Message...").isNotEmpty()
    }

    private fun handleDmSingleMedia(
        event: AccessibilityEvent,
        root: AccessibilityNodeInfo,
        now: Long
    ) {
        if (currentContext != ScreenContext.DM_SINGLE_MEDIA) {
            currentContext = ScreenContext.DM_SINGLE_MEDIA
            dmMediaEnteredMs = now
            dmInitialMediaFingerprint = extractMediaFingerprint(root)
            return
        }

        // Give the initial DM post 700ms to finish its opening animation
        if (now - dmMediaEnteredMs < 700L) {
            if (dmInitialMediaFingerprint.isNullOrBlank()) {
                dmInitialMediaFingerprint = extractMediaFingerprint(root)
            }
            return
        }

        // Trigger 1: User attempted to scroll vertically inside the DM post/reel viewer
        val isVerticalScroll = event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED &&
            (event.scrollDeltaY != 0 || event.fromIndex > 0)

        // Trigger 2: The visible post/reel author/caption changed to a different item
        val currentFingerprint = extractMediaFingerprint(root)
        val itemChanged = !dmInitialMediaFingerprint.isNullOrBlank() &&
            !currentFingerprint.isNullOrBlank() &&
            currentFingerprint != dmInitialMediaFingerprint

        if ((isVerticalScroll || itemChanged) && canTriggerAction(now)) {
            prefs.incrementDmScrollBlocked()
            currentContext = ScreenContext.DM_THREAD
            dmInitialMediaFingerprint = null
            navigateAway("Scrolling after DM post is blocked")
        }
    }

    private fun extractMediaFingerprint(root: AccessibilityNodeInfo): String? {
        for (id in MEDIA_AUTHOR_IDS) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$INSTAGRAM_PACKAGE:id/$id")
            val text = nodes.firstOrNull { !it.text.isNullOrBlank() }?.text?.toString()
            if (!text.isNullOrBlank()) return text.trim()
        }
        return null
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    private fun canTriggerAction(now: Long): Boolean = (now - lastActionMs) > ACTION_COOLDOWN_MS

    private fun navigateAway(message: String) {
        lastActionMs = SystemClock.elapsedRealtime()
        performGlobalAction(GLOBAL_ACTION_BACK)
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun clickNodeByExactText(root: AccessibilityNodeInfo, text: String): Boolean {
        val matches = root.findAccessibilityNodeInfosByText(text)
        for (node in matches) {
            if (!node.isVisibleToUser) continue
            if (node.text?.toString()?.equals(text, ignoreCase = true) == true) {
                if (clickSelfOrParent(node)) return true
            }
        }
        return false
    }

    private fun findBoundsByContentDesc(
        node: AccessibilityNodeInfo,
        keywords: List<String>,
        depth: Int = 0
    ): Rect? {
        if (depth > 8) return null
        val desc = node.contentDescription?.toString()?.lowercase()
        if (desc != null && keywords.any { desc == it || desc.startsWith("$it,") }) {
            val rect = Rect()
            node.getBoundsInScreen(rect)
            if (rect.width() > 10 && rect.height() > 10) return rect
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findBoundsByContentDesc(child, keywords, depth + 1)
            if (found != null) return found
        }
        return null
    }

    companion object {
        private const val INSTAGRAM_PACKAGE = "com.instagram.android"
        private const val ACTION_COOLDOWN_MS = 650L
        private const val DM_TRANSITION_WINDOW_MS = 3500L
        private const val FOLLOWING_RETRY_INTERVAL_MS = 6000L

        private val HOME_TAB_IDS = listOf("feed_tab", "tab_home")
        private val REELS_TAB_IDS = listOf("clips_tab", "reels_tab")
        private val EXPLORE_TAB_IDS = listOf("search_tab", "explore_tab")
        private val REELS_DESC_KEYWORDS = listOf("reels")
        private val EXPLORE_DESC_KEYWORDS = listOf("search and explore", "explore")

        private val REELS_VIEWER_IDS = listOf(
            "clips_viewer_view_pager",
            "clips_video_container",
            "clips_swipe_refresh_container"
        )
        private val EXPLORE_SURFACE_IDS = listOf(
            "explore_grid",
            "discovery_surface",
            "action_bar_search_edit_text"
        )
        private val POST_VIEWER_IDS = listOf(
            "row_feed_photo_imageview",
            "media_group",
            "zoomable_view_container"
        )
        private val HEADER_LOGO_IDS = listOf(
            "title_logo",
            "action_bar_title",
            "feed_title_logo",
            "logo_chevron",
            "feed_title_chevron"
        )
        private val FOLLOW_BUTTON_IDS = listOf(
            "follow_button",
            "row_feed_button_follow",
            "inline_follow_button"
        )
        private val DM_THREAD_IDS = listOf(
            "row_thread_composer_edittext",
            "message_list",
            "thread_title"
        )
        private val MEDIA_AUTHOR_IDS = listOf(
            "clips_author_username",
            "row_feed_photo_profile_name",
            "username"
        )
        private val SUGGESTED_PHRASES = listOf(
            "Suggested for you",
            "Suggested reels",
            "Suggested reel",
            "Because you watched",
            "Suggested Posts",
            "Recommended for you"
        )
    }
}
