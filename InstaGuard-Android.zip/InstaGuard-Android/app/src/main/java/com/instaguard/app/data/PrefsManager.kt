package com.instaguard.app.data

import android.content.Context
import android.content.SharedPreferences
import java.time.LocalDate

class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("instaguard_prefs", Context.MODE_PRIVATE)

    var blockReelsTab: Boolean
        get() = prefs.getBoolean(KEY_BLOCK_REELS, true)
        set(value) = prefs.edit().putBoolean(KEY_BLOCK_REELS, value).apply()

    var blockExploreTab: Boolean
        get() = prefs.getBoolean(KEY_BLOCK_EXPLORE, true)
        set(value) = prefs.edit().putBoolean(KEY_BLOCK_EXPLORE, value).apply()

    var overlayBlockBottomButtons: Boolean
        get() = prefs.getBoolean(KEY_OVERLAY_SHIELD, true)
        set(value) = prefs.edit().putBoolean(KEY_OVERLAY_SHIELD, value).apply()

    var autoSwitchFollowingFeed: Boolean
        get() = prefs.getBoolean(KEY_AUTO_FOLLOWING, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_FOLLOWING, value).apply()

    var blockSuggestedPosts: Boolean
        get() = prefs.getBoolean(KEY_BLOCK_SUGGESTED, true)
        set(value) = prefs.edit().putBoolean(KEY_BLOCK_SUGGESTED, value).apply()

    var allowSingleDmPostOnly: Boolean
        get() = prefs.getBoolean(KEY_DM_SINGLE_POST, true)
        set(value) = prefs.edit().putBoolean(KEY_DM_SINGLE_POST, value).apply()

    var strictModeEnabled: Boolean
        get() = prefs.getBoolean(KEY_STRICT_MODE, false)
        set(value) = prefs.edit().putBoolean(KEY_STRICT_MODE, value).apply()

    private fun resetCountersIfNewDay() {
        val today = LocalDate.now().toString()
        if (prefs.getString(KEY_STATS_DATE, "") != today) {
            prefs.edit()
                .putString(KEY_STATS_DATE, today)
                .putInt(KEY_COUNT_REELS, 0)
                .putInt(KEY_COUNT_EXPLORE, 0)
                .putInt(KEY_COUNT_DM_SCROLL, 0)
                .putInt(KEY_COUNT_SUGGESTED, 0)
                .apply()
        }
    }

    fun incrementReelsBlocked() {
        resetCountersIfNewDay()
        prefs.edit().putInt(KEY_COUNT_REELS, getReelsBlockedToday() + 1).apply()
    }

    fun incrementExploreBlocked() {
        resetCountersIfNewDay()
        prefs.edit().putInt(KEY_COUNT_EXPLORE, getExploreBlockedToday() + 1).apply()
    }

    fun incrementDmScrollBlocked() {
        resetCountersIfNewDay()
        prefs.edit().putInt(KEY_COUNT_DM_SCROLL, getDmScrollBlockedToday() + 1).apply()
    }

    fun incrementSuggestedBlocked() {
        resetCountersIfNewDay()
        prefs.edit().putInt(KEY_COUNT_SUGGESTED, getSuggestedBlockedToday() + 1).apply()
    }

    fun getReelsBlockedToday(): Int {
        resetCountersIfNewDay()
        return prefs.getInt(KEY_COUNT_REELS, 0)
    }

    fun getExploreBlockedToday(): Int {
        resetCountersIfNewDay()
        return prefs.getInt(KEY_COUNT_EXPLORE, 0)
    }

    fun getDmScrollBlockedToday(): Int {
        resetCountersIfNewDay()
        return prefs.getInt(KEY_COUNT_DM_SCROLL, 0)
    }

    fun getSuggestedBlockedToday(): Int {
        resetCountersIfNewDay()
        return prefs.getInt(KEY_COUNT_SUGGESTED, 0)
    }

    companion object {
        private const val KEY_BLOCK_REELS = "block_reels_tab"
        private const val KEY_BLOCK_EXPLORE = "block_explore_tab"
        private const val KEY_OVERLAY_SHIELD = "overlay_shield"
        private const val KEY_AUTO_FOLLOWING = "auto_following_feed"
        private const val KEY_BLOCK_SUGGESTED = "block_suggested_posts"
        private const val KEY_DM_SINGLE_POST = "dm_single_post_only"
        private const val KEY_STRICT_MODE = "strict_mode"
        private const val KEY_STATS_DATE = "stats_date"
        private const val KEY_COUNT_REELS = "count_reels"
        private const val KEY_COUNT_EXPLORE = "count_explore"
        private const val KEY_COUNT_DM_SCROLL = "count_dm_scroll"
        private const val KEY_COUNT_SUGGESTED = "count_suggested"
    }
}
